-- BUDY Restaurant - Supabase/PostgreSQL schema
create extension if not exists pgcrypto;

create table if not exists public.menu_items (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null default 'أخرى',
  description text not null default '',
  price numeric(10,2) not null check (price >= 0),
  image_url text not null default '',
  available boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null,
  phone text not null,
  address text not null,
  notes text not null default '',
  items jsonb not null,
  subtotal numeric(10,2) not null check (subtotal >= 0),
  discount numeric(10,2) not null default 0 check (discount >= 0),
  total numeric(10,2) not null check (total >= 0),
  status text not null default 'new' check (status in ('new','confirmed','preparing','ready','delivered','cancelled')),
  created_at timestamptz not null default now()
);

alter table public.menu_items enable row level security;
alter table public.orders enable row level security;

-- Public customers can read available menu items.
create policy "public read available menu"
on public.menu_items for select
using (available = true);

-- Only the configured admin account can manage menu and read/manage orders.
create policy "admin manage menu"
on public.menu_items for all
using ((auth.jwt() ->> 'email') = 'budy@gmail.com')
with check ((auth.jwt() ->> 'email') = 'budy@gmail.com');

create policy "public create orders"
on public.orders for insert
with check (true);

create policy "admin read orders"
on public.orders for select
using ((auth.jwt() ->> 'email') = 'budy@gmail.com');

create policy "admin update orders"
on public.orders for update
using ((auth.jwt() ->> 'email') = 'budy@gmail.com')
with check ((auth.jwt() ->> 'email') = 'budy@gmail.com');

-- Prevent anonymous users from modifying/deleting orders.
revoke update, delete on public.orders from anon;
grant insert on public.orders to anon;
grant select on public.menu_items to anon;
