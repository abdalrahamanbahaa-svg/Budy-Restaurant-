// Copy this file to config.local.js and replace the placeholders.
// Do NOT put the Supabase service_role key in the browser.
window.BUDY_CONFIG = {
  SUPABASE_URL: 'https://YOUR_PROJECT.supabase.co',
  SUPABASE_ANON_KEY: 'YOUR_SUPABASE_ANON_KEY'
};
