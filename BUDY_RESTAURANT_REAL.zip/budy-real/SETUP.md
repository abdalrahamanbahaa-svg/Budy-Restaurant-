# BUDY Restaurant — Real Production Setup

## 1. Database
1. Create a Supabase project.
2. Open SQL Editor and run `supabase_schema.sql`.
3. In Authentication → Users, create the admin user with email `budy@gmail.com`.
4. Use a strong password. The old `2013` password is intentionally not hard-coded into the site; change it before production.
5. Copy the project's URL and **anon/public** key into `config.local.js`.

## 2. Local config
Copy `config.local.js.example` to `config.local.js` and fill in:
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`

Never expose a `service_role` key in the website.

## 3. What is now real
- Menu is stored in PostgreSQL/Supabase.
- Customers submit orders into the database.
- Admin logs in through Supabase Auth.
- Row Level Security prevents normal users from reading/managing orders or changing the menu.
- Admin can add/delete menu items and advance order status.

## 4. Deployment
Upload all files to any static host (Vercel/Netlify/GitHub Pages) after adding `config.local.js`.

For Vercel, make sure the config file is included in the deployment. For a production-grade setup, move these two public values into your frontend build environment rather than committing them.

## 5. Important production notes
- Add your real restaurant phone/address.
- Add a custom domain.
- Configure Supabase Auth email settings and your site's allowed redirect URL.
- Consider adding a payment gateway later; current orders are cash/manual orders.
