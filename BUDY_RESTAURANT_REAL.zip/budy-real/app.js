const cfg=window.BUDY_CONFIG||{};
const sb=(cfg.SUPABASE_URL&&cfg.SUPABASE_ANON_KEY&&window.supabase)?supabase.createClient(cfg.SUPABASE_URL,cfg.SUPABASE_ANON_KEY):null;
let menu=[],cart=JSON.parse(localStorage.getItem('budyCart')||'[]'),activeCat='الكل',discount=0;
async function loadMenu(){
 if(!sb){toast('أكمل إعداد قاعدة البيانات أولًا');return}
 const {data,error}=await sb.from('menu_items').select('*').eq('available',true).order('created_at',{ascending:false});
 if(error){console.error(error);toast('تعذر تحميل المنيو');return} menu=data||[]; renderFilters();renderMenu();save();
}
function renderFilters(){const cats=['الكل',...new Set(menu.map(x=>x.category))];document.getElementById('filters').innerHTML=cats.map(c=>`<button class="filter ${c===activeCat?'active':''}" onclick="setCat('${esc(c)}')">${esc(c)}</button>`).join('')}
function setCat(c){activeCat=c;renderFilters();renderMenu()}
function renderMenu(){const list=activeCat==='الكل'?menu:menu.filter(x=>x.category===activeCat);document.getElementById('menuGrid').innerHTML=list.map(x=>`<article class="food-card"><img class="food-img" src="${esc(x.image_url)}" alt="${esc(x.name)}"><div class="food-info"><h3>${esc(x.name)}</h3><p>${esc(x.description)}</p><div class="food-bottom"><span class="price">${Number(x.price).toFixed(0)} جنيه</span><button class="add" onclick="addToCart('${x.id}')">+</button></div></div></article>`).join('')}
function addToCart(id){const item=menu.find(x=>x.id===id);if(!item)return;const f=cart.find(x=>x.id===id);f?f.qty++:cart.push({id:item.id,name:item.name,price:Number(item.price),qty:1});save();toast('تمت إضافة الوجبة إلى السلة 🍔')}
function save(){localStorage.setItem('budyCart',JSON.stringify(cart));document.getElementById('cartCount').textContent=cart.reduce((s,x)=>s+x.qty,0)}
function openCart(){renderCart();document.getElementById('cartModal').classList.add('show')}function closeCart(){document.getElementById('cartModal').classList.remove('show')}
function renderCart(){const el=document.getElementById('cartItems');if(!cart.length)el.innerHTML='<p style="color:#999;text-align:center;padding:35px">السلة فارغة حاليًا 🛒</p>';else el.innerHTML=cart.map(x=>`<div class="cart-row"><div><b>${esc(x.name)}</b><small style="display:block;color:#999">${x.qty} × ${x.price} جنيه</small></div><div><strong>${x.qty*x.price} جنيه</strong> <button onclick="removeItem('${x.id}')">حذف</button></div></div>`).join('');const total=cart.reduce((s,x)=>s+x.price*x.qty,0)*(1-discount);document.getElementById('cartTotal').textContent=Math.round(total)+' جنيه'}
function removeItem(id){cart=cart.filter(x=>x.id!==id);save();renderCart()}
function applyOffer(){discount=.1;toast('تم تفعيل خصم 10% 🎉');openCart()}
async function checkout(){if(!cart.length)return toast('أضف وجبة للسلة أولًا');const customer_name=prompt('اسمك بالكامل:');if(!customer_name)return;const phone=prompt('رقم الهاتف:');if(!phone)return;const address=prompt('العنوان بالتفصيل:');if(!address)return;const notes=prompt('ملاحظات (اختياري):')||'';const subtotal=cart.reduce((s,x)=>s+x.price*x.qty,0),disc=Math.round(subtotal*discount*100)/100,total=Math.round((subtotal-disc)*100)/100;const payload={customer_name,phone,address,notes,items:cart,subtotal,discount:disc,total};if(!sb)return toast('قاعدة البيانات غير مهيأة');const {error}=await sb.from('orders').insert(payload);if(error){console.error(error);return toast('حدث خطأ أثناء إرسال الطلب')}cart=[];discount=0;save();closeCart();toast('تم استلام طلبك بنجاح ❤️')}
function toast(msg){const t=document.getElementById('toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2600)}
function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
loadMenu();save();
